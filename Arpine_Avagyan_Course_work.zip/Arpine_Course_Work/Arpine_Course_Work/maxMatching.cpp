#include "pch.h"
#include "maxMatching.h"
#include <iostream>
#include <fstream>

void Graph::addNeighbor()
{
	std::ifstream input("Graph.txt");
    input >> number_of_vertices;
	input >> number_of_edges;
    int tmp_1;
    int tmp_2;
    adjacency_list.resize(number_of_vertices);
    for (int i = 0; i < number_of_edges; i++)
    {
        input >> tmp_1;
        input >> tmp_2;
        adjacency_list[tmp_1].push_back(tmp_2);
        adjacency_list[tmp_2].push_back(tmp_1);              
    }	
}

void Graph::printAdjacencyList()
{
	std::cout << " *** Adjacency List ***";
	for (int i = 0; i < adjacency_list.size(); ++i)
	{
		std::cout << std::endl << i << ":";
		for (int j = 0; j < adjacency_list[i].size(); ++j)
		{
			if (i < 10)
				std::cout << "   " << adjacency_list[i][j];
			else
				std::cout << "  " << adjacency_list[i][j];
		}
	}
	std::cout << std::endl;
}

void Graph::DFSUtil(int v, bool visited[], int i)
{
	visited[v] = true;
	adj[i].push_back(v);

	for (int j = 0; j < adjacency_list[v].size(); ++j)
	{
		if (!visited[adjacency_list[v][j]])
		{
			DFSUtil(adjacency_list[v][j], visited, i);
		}
	}
}

void Graph::connectedComponents()
{
	bool *visited = new bool[number_of_vertices];
	for (int v = 0; v < number_of_vertices; v++)
		visited[v] = false;
	int i = 0;

	for (int v = 0; v < number_of_vertices; v++)
	{
		if (visited[v] == false)
		{
			adj.resize(i + 1);
			Edges.resize(i + 1);
			DFSUtil(v, visited, i);
			findEdges(i);
			i++;
		}
	}
	delete[] visited;
}

void Graph::findEdges(int i)
{
	for (int k = 0; k < adj[i].size(); ++k)
	{
		for (int j = 0; j < adjacency_list[adj[i][k]].size(); ++j)
		{
			if (adjacency_list[adj[i][k]][j] > adj[i][k])
			{
				Edges[i].push_back(std::make_pair(adj[i][k], adjacency_list[adj[i][k]][j]));
			}
		}
	}
}

void Graph::printEdges()
{
	std::cout << "\n\n *** Edge List ***";
	for (int i = 0; i < Edges.size(); ++i)
	{
		int value = i % 100;

		if (3 < value && value < 21)
			std::cout << "\n For the " << i + 1 << "th component of the Graph: ";

		switch (value % 10)
		{
		case 0: std::cout << "\n For the " << i + 1 << "st component of the Graph: ";
			break;
		case 1: std::cout << "\n For the " << i + 1 << "nd component of the Graph: ";
			break;
		case 2: std::cout << "\n For the " << i + 1 << "rd component of the Graph: ";
			break;
		default: std::cout << "\n For the " << i + 1 << "th component of the Graph: ";
		}

		for (int j = 0; j < Edges[i].size(); ++j)
		{
			std::cout << "  {" << Edges[i][j].first << "," << Edges[i][j].second << "}";
		}
	}
}

int Graph::helper()
{
	int sum = 0;
	for (int i = 0; i < Edges.size(); ++i)
	{
		sum += findMaxMatching(Edges[i], i);
	}
	return sum;
}

int Graph::findMaxMatching(std::vector<std::pair<int, int>> tmpEdgeList, int a)
{
	std::vector<std::pair<int, int>> maxMatching;
	int q, a1, a2, b1, b2, max = 0;
	int value = a % 100;

	if (3 < value && value < 21)
		std::cout << "\n\n *** For the " << a + 1 << "th component of the Graph ***";

	switch (value % 10)
	{
	case 0: std::cout << "\n\n *** For the " << a + 1 << "st component of the Graph ***";
		break;
	case 1: std::cout << "\n\n *** For the " << a + 1 << "nd component of the Graph ***";
		break;
	case 2: std::cout << "\n\n *** For the " << a + 1 << "rd component of the Graph ***";
		break;
	default: std::cout << "\n\n *** For the " << a + 1 << "th component of the Graph ***";
	}

	for (int i = 0; i < adjacency_list[adj[a][0]].size(); ++i)
	{
		maxMatching.clear();
		maxMatching.push_back(std::make_pair(adj[a][0], adjacency_list[adj[a][0]][i]));

		while (!tmpEdgeList.empty())
		{
			for (int j1 = 0; j1 < tmpEdgeList.size(); )
			{
				a1 = tmpEdgeList[j1].first;
				a2 = tmpEdgeList[j1].second;
				for (int j2 = 0; j2 < maxMatching.size(); ++j2)
				{
					b1 = maxMatching[j2].first;
					b2 = maxMatching[j2].second;
					if (a1 == b1 || a1 == b2 || a2 == b1 || a2 == b2)
					{
						if (j2 != 0)
						{
							if (j2 != maxMatching.size() - 1)
							{
								j1++;
								break;
							}
							j1++;
						}
						else
						{
							tmpEdgeList.erase(tmpEdgeList.begin() + j1);
							break;
						}
					}
					else if (j2 == maxMatching.size() - 1)
					{
						maxMatching.push_back(std::make_pair(a1, a2));
						tmpEdgeList.erase(tmpEdgeList.begin() + j1);
						break;
					}
				}
			}
			std::cout << "\n maxMatching:";
			for (int j = 0; j < maxMatching.size(); ++j)
			{
				std::cout << "  {" << maxMatching[j].first << "," << maxMatching[j].second << "}";
			}
			if (maxMatching.size() > max)
			{
				max = maxMatching.size();
			}
			maxMatching.erase(maxMatching.begin() + 1, maxMatching.end());
		}
	}
	return max;
}
