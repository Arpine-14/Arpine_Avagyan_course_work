#pragma once
#include <vector>

class Graph
{
private:
	int number_of_vertices;
	int number_of_edges;
	std::vector<std::vector<int>> adjacency_list;
	std::vector<std::vector<int>> adj;
	std::vector<std::vector<std::pair<int, int>>> Edges;
public:
	void addNeighbor();
	void printAdjacencyList();
	void DFSUtil(int, bool [], int);
	void connectedComponents();
	void findEdges(int);
	int helper();
	void printEdges();
	int findMaxMatching(std::vector<std::pair<int, int>>, int);
};

