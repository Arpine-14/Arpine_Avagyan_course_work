#include "pch.h"
#include "maxMatching.h"
#include <iostream>

int main()
{
	Graph G;
	G.addNeighbor();

	G.printAdjacencyList();

	G.connectedComponents();

	G.printEdges();

	std::cout << "\n\n THE NUMBER OF MAXIMUM MATCHING FOR WHOLE GRAPH IS: " << G.helper() << '\n';

	return 0;
}

